<?php
/**
 * Created by PhpStorm.
 * User: mohsin
 * Date: 8/26/2017
 * Time: 8:05 PM
 */
?>
<!--Footer-part-->

<div class="row-fluid">
    <div id="footer" class="span12"> 2013 &copy;  Admin. Brought to you by <a href="http://dragonitbd.com">dragonitbd.com</a> </div>
</div>

<!--end-Footer-part-->
<script src="<?php echo e(asset('backend/js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/js/excanvas.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/js/jquery.ui.custom.js')); ?>"></script>
<script src="<?php echo e(asset('backend/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/js/jquery.peity.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/js/bootstrap-colorpicker.js')); ?>"></script>
<script src="<?php echo e(asset('backend/js/fullcalendar.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/js/matrix.js')); ?>"></script>
<script src="<?php echo e(asset('backend/js/matrix.dashboard.js')); ?>"></script>
<script src="<?php echo e(asset('backend/js/jquery.gritter.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/js/matrix.interface.js')); ?>"></script>
<script src="<?php echo e(asset('backend/js/matrix.chat.js')); ?>"></script>
<script src="<?php echo e(asset('backend/js/jquery.validate.js')); ?>"></script>
<script src="<?php echo e(asset('backend/js/matrix.form_validation.js')); ?>"></script>
<script src="<?php echo e(asset('backend/js/jquery.wizard.js')); ?>"></script>
<script src="<?php echo e(asset('backend/js/jquery.uniform.js')); ?>"></script>
<script src="<?php echo e(asset('backend/js/select2.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/js/matrix.popover.js')); ?>"></script>
<script src="<?php echo e(asset('backend/js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/js/matrix.tables.js')); ?>"></script>
<script src="<?php echo e(asset('backend/js/wysihtml5-0.3.0.js')); ?>"></script>
<script src="<?php echo e(asset('backend/js/bootstrap-wysihtml5.js')); ?>"></script>
<script src="<?php echo e(asset('backend/js/matrix.form_common.js')); ?>"></script>

<script type="text/javascript">
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
    // This function is called from the pop-up menus to transfer to
    // a different page. Ignore if the value returned is a null string:
    function goPage (newURL) {

        // if url is empty, skip the menu dividers and reset the menu selection to default
        if (newURL != "") {

            // if url is "-", it is this page -- reset the menu:
            if (newURL == "-" ) {
                resetMenu();
            }
            // else, send page to designated URL
            else {
                document.location.href = newURL;
            }
        }
    }

    // resets the menu selection upon entry to this page:
$(function() {
    function resetMenu() {
        document.gomenu.selector.selectedIndex = 2;
    }
    if(document.querySelector(".textarea_editor")){
        //$('.textarea_editor').wysihtml5();
        $(".textarea_editor").each(function(){$(this).wysihtml5();});
    }

    var flag = 1; // used for calling

    if(document.querySelector(".deleteRow")){

        $(".deleteRow").click(function(e) {
            var $this =   $(this);

            var id = $this.attr('data-primaryId');
            var route = $this.attr('href');
            var markers = [{ "id": id, "_token": "7" }];
        //    console.log('id='+id+" route="+route)
            var r = confirm("Are you Sure!!!");

            if (flag == 1) {
                if (r == true) {
                    flag = 0;
                    $.ajax({
                        url: route,
                        type:'POST',
                        dataType:'json',
                        data: {_token : "<?php echo e(csrf_token()); ?>", id:id},
                        success: function(data) {
                            flag = 1;
                            if(data.error==false){
                                $this.parent().parent().remove();
                            }
                        }
                    });
                } else {

                }

            }


        });
    }

});





</script>
