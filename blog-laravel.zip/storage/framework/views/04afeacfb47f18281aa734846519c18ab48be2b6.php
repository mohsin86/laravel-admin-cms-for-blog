<?php
/**
 * Created by PhpStorm.
 * User: mohsin
 * Date: 8/27/2017
 * Time: 3:31 PM
 */


?>
<div class="widget-content nopadding">

    <div class="todo">
        <table class="table table-bordered data-table">
            <thead>
                <tr>
                    <th>Number</th>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Email</th>
                    <th>Profile Image</th>
                    <th>Company Name</th>
                    <th>Designation</th>
                    <th>Extra Info</th>
                    <th>source</th>
                    <th>Valid</th>
                    <th>Action</th>

                </tr>

            </thead>
            <tbody>
            <?php $i = 1; ?>
            <?php $__currentLoopData = $leads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lead): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             <tr class="grade ">
                 <td><div class="txt"> <?php echo e($i++); ?></div></td>
                 <td><div class="txt"><a href="<?php echo e($lead->profile_url); ?>" target="_blank"> <?php echo e($lead->first_name); ?></a></div></td>
                 <td><div class="txt"><a href="<?php echo e($lead->profile_url); ?>" target="_blank"> <?php echo e($lead->last_name); ?></a></div></td>
                 <td><div class="txt"> <?php echo e($lead->email); ?></div></td>
                 <td><div class="txt">
                       <?php if($lead->profile_image!=''): ?>
                         <a href="<?php echo e(asset($lead->profile_image)); ?>" target="_blank"><img src="<?php echo e(asset($lead->profile_image)); ?>" width="100"></a> </div></td>
                        <?php endif; ?>
                 <td><div class="txt"><a href="<?php echo e($lead->company_url); ?>" target="_blank">  <?php echo e($lead->company_name); ?></a></div></td>
                 <td><div class="txt"> <?php echo e($lead->designation); ?></div></td>
                 <td><div class="txt"> <?php echo e($lead->extra_info); ?></div></td>
                 <td><div class="txt"> <?php echo e($lead->source); ?></div></td>

                 <td><div class="txt"> <?php echo e($lead->valid); ?></div></td>
                 <td><div class="pull-right">
                         <a  href="<?php echo e(route('editLead',['id'=>$lead->id])); ?>" title="Edit Task"><i class="icon-pencil"></i></a>
                         <a id="deleteLead" data-leadId="<?php echo e($lead->id); ?>" onclick="javascript:return false;" title="Delete"><i class="icon-remove"></i></a>
                     </div>
                 </td>
             </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
