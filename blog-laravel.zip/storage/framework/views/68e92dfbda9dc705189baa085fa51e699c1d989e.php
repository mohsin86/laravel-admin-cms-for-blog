<?php
/**
 * Created by PhpStorm.
 * User: mohammed.mohasin
 * Date: 28-Aug-17
 * Time: 2:14 PM
 */
?>
<form action="<?php echo e(route('updatepage',['id'=>$contents->id])); ?>" method="post" class="form-horizontal" enctype="multipart/form-data">
    <?php echo e(csrf_field()); ?>

    <div class="control-group">
        <label class="control-label">Page Title :</label>
        <div class="controls">
            <input class="span11" name="page_title" value="<?php echo e($contents->page_title); ?>" placeholder="Page Title" type="text">
        </div>
    </div>
    <div class="control-group">
        <label class="control-label">Page Subtitle :</label>
        <div class="controls">
            <input class="span11" name="page_subtitle" value="<?php echo e($contents->page_title); ?>" placeholder="Page Subtitle" type="text">
        </div>
    </div>
    <div class="control-group">
        <label class="control-label">Featured Image</label>
        <div class="controls">

            <input type="file" name="page_featured_image" id="input-file" />
            <img src="<?php echo e(asset($contents->page_featured_image)); ?>" width="100" />
            <input type="hidden" value="<?php echo e($contents->page_featured_image); ?>" name="page_old_url"  />
            <?php if($contents->page_featured_image!=''): ?>
                <a href="<?php echo e(asset($contents->page_featured_image)); ?>" target="_blank"><img src="<?php echo e(asset($lead->page_featured_image)); ?>" width="100"></a>
            <?php endif; ?>
        </div>
    </div>
    <div class="control-group">
        <label class="control-label">Body</label>
        <div class="controls">
            <textarea class="textarea_editor span10" name="page_body" rows="10"  placeholder="Enter text ..."><?php echo e($contents->page_body); ?></textarea>
        </div>
    </div>

    <div class="form-actions">
        <button type="submit" class="btn btn-success">Save</button>
    </div>
</form>
