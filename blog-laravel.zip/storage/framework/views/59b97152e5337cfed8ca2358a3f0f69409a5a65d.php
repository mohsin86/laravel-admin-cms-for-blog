<?php $__env->startSection('content'); ?>
    <!--breadcrumbs-->
    <div id="content-header">
        <div id="breadcrumb"><a href="<?php echo e(url('admin')); ?>" title="Go to Home" class="tip-bottom"><i class="icon-home"></i>
                Home</a></div>
    </div>
    <!--End-breadcrumbs-->

    <!--Action boxes-->
    <div class="container-fluid">
    
    
    
    
    
    
    
    
    
    
    
    

    
    
    <!--End-Action boxes-->

        <!--Chart-box-->

        <!--End-Chart-box-->
        <hr/>
        <div class="row-fluid">

            <?php echo $__env->make('admin.includes.error-succes-message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <style>
                input, textarea, .uneditable-input {
                    width: 60%;
                }
            </style>
            <div class="span10">

                <div class="widget-box">
                    <div class="widget-title"><span class="icon"><i class="icon-ok"></i></span>
                        <h5>Lead Generation</h5>
                        <?php if($display=='list'): ?>
                        <a href="#" class="btn btn-success pull-right">Generate Excel </a>

                        <a href="<?php echo e(route('AddLead')); ?>" class="btn btn-success pull-right mr3" style="margin-right: 10px">Add </a>
                        <?php else: ?>
                            <a href="<?php echo e(url('admin')); ?>" class="btn btn-success pull-right">Back </a>
                        <?php endif; ?>
                    </div>
                    <?php if($display=='list'): ?>
                        <?php echo $__env->make('admin.includes.leads.leadList', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <?php endif; ?>

                    <?php if($display=='add'): ?>
                           <?php echo $__env->make('admin.includes.leads.addLead', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                    <?php endif; ?>
                    <?php if($display =='edit'): ?>
                        <?php echo $__env->make('admin.includes.leads.editLead', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                    <?php endif; ?>
                </div>


            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.layouts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>