<?php
/**
 * Created by PhpStorm.
 * User: mohsin
 * Date: 8/26/2017
 * Time: 8:14 PM
 */
?>
<?php
$dashbaord = '';
$page_name = '';
$clients= '';
$pricing= '';
$testimonial = '';
$settings = '';
$user = '';
$team = '';
switch ($page) {
    case 'dashboard':
        $dashbaord = 'active';
        break;
    case 'page':
        $page_name = 'active open';
        break;
    case 'clients':
        $clients= 'active open';
        break;
    case 'pricing':
        $pricing= 'active open';
        break;
    case 'testimonial':
        $testimonial= 'active open';
        break;
    case 'settings':
        $settings= 'active';
        break;
    case 'user':
        $settings= 'active';
        break;
    default:
        $dashbaord = 'active';
}


?>

<!--sidebar-menu-->
<div id="sidebar"><a href="<?php echo e(url('admin')); ?>" class="visible-phone"><i class="icon icon-home"></i> Dashboard</a>
    <ul>
        <li class="<?php echo e($dashbaord); ?>"><a href="<?php echo e(url('admin')); ?>"><i class="icon icon-home"></i> <span>Dashboard</span></a> </li>
        <li class="submenu <?php echo e($page_name); ?>">
            <a href="<?php echo e(url('admin/page')); ?>"><i class="icon icon-th-list"></i> <span>Page</span></a>
            <ul>

                <li><a href="<?php echo e(route('pageList')); ?>">Page List</a></li>
                <li><a href="<?php echo e(route('addpage')); ?>">Add Page</a></li>
            </ul>
        </li>

        <li class="submenu <?php echo e($testimonial); ?>">
            <a href="<?php echo e(url('admin/pricing')); ?>"><i class="icon icon-th"></i> <span>Pricing</span> </a>
            <ul>
                <li><a href="<?php echo e(url('admin/addpricing')); ?>">Add Pricing</a></li>
            </ul>
        </li>

        <li class="submenu <?php echo e($clients); ?>">
            <a href="<?php echo e(url('admin/clients')); ?>"><i class="icon icon-fullscreen"></i> <span>Clients</span> </a>
            <ul>
                <li><a href="<?php echo e(url('admin/addpricing')); ?>">Add Clients</a></li>
            </ul>
        </li>
        <li class="submenu <?php echo e($testimonial); ?>">
            <a href="<?php echo e(url('admin/testimonial')); ?>"><i class="icon icon-fullscreen"></i> <span>Testimonial</span> </a>
            <ul>
                <li><a href="<?php echo e(url('admin/addtestimonial')); ?>">Add Testimonial</a></li>
            </ul>
        </li>
        <li class="submenu <?php echo e($team); ?>">
            <a href="<?php echo e(url('admin/team')); ?>"><i class="icon icon-fullscreen"></i> <span>Team</span> </a>
            <ul>
                <li><a href="<?php echo e(url('admin/teamList')); ?>">Team List</a></li>
                <li><a href="<?php echo e(url('admin/addTeam')); ?>">Add Team</a></li>
            </ul>
        </li>
        <li class="submenu <?php echo e($user); ?>">
            <a href="<?php echo e(url('admin/userList')); ?>"><i class="icon icon-fullscreen"></i> <span>User</span> </a>
            <ul>
                <li><a href="<?php echo e(url('admin/userList')); ?>">User List</a></li>
                <li><a href="<?php echo e(url('admin/addUser')); ?>">Add User</a></li>
            </ul>
        </li>

        <li class="<?php echo e($settings); ?>"> <a href="<?php echo e(url('admin/settings')); ?>"><i class="icon icon-inbox"></i> <span>Settings</span></a> </li>


        

        
        
        
            
                
                
                
                
                
            
        


    </ul>
</div>
<!--sidebar-menu-->
