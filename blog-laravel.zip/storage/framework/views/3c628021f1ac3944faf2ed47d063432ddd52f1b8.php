<!doctype html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <?php echo $__env->make('includes.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</head>
<body>
<!--
    ==================================================
    Header Section Start
    ================================================== -->
<header id="top-bar" class="navbar-fixed-top animated-header">

    <?php echo $__env->make('includes.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

</header>

<?php echo $__env->yieldContent('content'); ?>

<!--
            ==================================================
            Footer Section Start
            ================================================== -->
<footer id="footer">
    <?php echo $__env->make('includes.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</footer>

</body>
</html>
