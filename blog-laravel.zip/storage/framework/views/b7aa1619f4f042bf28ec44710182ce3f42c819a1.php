<?php
/**
 * Created by PhpStorm.
 * User: mohammed.mohasin
 * Date: 28-Aug-17
 * Time: 2:12 PM
 */
?>

        <table class="table table-bordered">
            <thead>
            <tr>
                <th>No</th>
                <th>Title</th>
                <th>Image</th>
                <th>Action</th>
            </tr>
            </thead>
            <tbody>
            <?php
            $i = 1;
            ?>
            <?php $__currentLoopData = $contents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $content): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo $i++; ?></td>
                    <td><?php echo e($content->page_title); ?></td>
                    <td>  <?php if($content->page_featured_image!=''): ?>
                            <a href="<?php echo e(asset($content->page_featured_image)); ?>" target="_blank"><img src="<?php echo e(asset($content->page_featured_image)); ?>" width="100"></a>
                         <?php endif; ?>
                    </td>
                    <td>
                         <a href="<?php echo e(route('editpage',['id'=>$content->id])); ?>" data-original-title="Edit Page"><i class="icon-pencil"></i></a>
                         <a href="<?php echo e(route('deletepage')); ?>" class="deleteRow" data-primaryId="<?php echo e($content->id); ?>" onclick="javascript:return false" data-original-title="Delete"><i class="icon-remove"></i></a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
