<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Page;
use Illuminate\Support\Facades\Session;
class PageController extends Controller
{
    //
    public function index(){
        $display = 'list';
        $page = 'page';
        $contents = Page::all();
        return view('admin.page',compact('contents','display','page'));
    }

    public function addpage()
    {
        $display = 'add';
        $page = 'page';
        return view('admin.page',compact('display','page'));
    }

    public function editpage($id)
    {
        $display = 'edit';
        $page = 'page';
        $contents = Page::findOrFail($id);
        return view('admin.page',compact('contents','display','page'));
    }

    public function store(Request $request){
        $this->validate($request,[
            'page_title'=>'required',
            'page_body'=>'required',
        ]);
        $page_featured_image = '';
        If($request->hasFile('page_featured_image')){
            $file = $request->file('page_featured_image');
            $destinationPath = public_path(). '/uploads/Page';
            //Check if the directory already exists.
            if(!is_dir($destinationPath)){
                //Directory does not exist, so lets create it.
                mkdir($destinationPath, 0755, true);
            }
            $filename = $file->getClientOriginalName();

            $file->move($destinationPath, $filename);

            $page_featured_image =  'uploads/Page/'.$filename;
            //echo '<img src="uploads/Leads'. $filename . '"/>';
        }

        $lead_data = new Page([
            'page_title' => $request->get('page_title'),
            'page_subtitle' => $request->get('page_subtitle'),
            'page_body' => $request->get('page_body'),
            'page_featured_image' => $page_featured_image,
            'user_id' => '',
        ]);



        //PUT HERE AFTER YOU SAVE
        $request->session()->flash('alert-success', 'Page was successful added!');
        $lead_data->save();
        return redirect()->route('pageList');
    }

    public function update($id,Request $request){
        $data = Page::findOrFail($id);
        //dd($editleads);

        $this->validate($request,[
            'page_title'=>'required',
            'page_body'=>'required',
        ]);

        If($request->hasFile('page_featured_image')){
            $file = $request->file('page_featured_image');
            $destinationPath = public_path(). '/uploads/Page';
            //Check if the directory already exists.
            if(!is_dir($destinationPath)){
                //Directory does not exist, so lets create it.
                mkdir($destinationPath, 0755, true);
            }
            $filename = $file->getClientOriginalName();

            $file->move($destinationPath, $filename);

            $page_featured_image =  'uploads/Page/'.$filename;
            //echo '<img src="uploads/Leads'. $filename . '"/>';
        }else{
            $page_featured_image = $request->get('page_old_url');
        }

        $data->page_title = $request->get('page_title');
        $data->page_subtitle = $request->get('page_subtitle');
        $data->page_body = $request->get('page_body');
        $data->page_featured_image = $page_featured_image;

        $data->save();


        //dd($leads);
        return redirect('admin');


    }

    public function delete(Request $request){
       // dd($request);
        $id = $request->get('id');
        $error = false;
        //$token = $request->ajax() ? $request->header('X-CSRF-Token') : $request->get('_token');
        $msg = '';
        if($request->ajax())
        {
            if (Session::token() !== $request->header('X-CSRF-Token'))
            {
                $error = true;
                $msg = 'Token Mismatch';
            }
        }
        elseif (Session::token() !== $request->get('_token')){
            $error = true;
            $msg = 'Token Mismatch';
        }
        if(!$error){
            $pages = Page::find($id);
            $pages->delete();
            $msg = 'Successfully delteted';
        }


        return json_encode(array('msg'=> $msg,'error'=>$error,'id'=>$id));
        //return $id;

    }

}
