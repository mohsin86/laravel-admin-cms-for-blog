<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PageOptions extends Model
{
    //
}
