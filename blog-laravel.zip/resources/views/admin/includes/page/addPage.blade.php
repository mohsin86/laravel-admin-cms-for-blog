<?php
/**
 * Created by PhpStorm.
 * User: mohammed.mohasin
 * Date: 28-Aug-17
 * Time: 2:13 PM
 */
?>


<form action="{{route('storepage')}}" method="post" class="form-horizontal" enctype="multipart/form-data">
    {{csrf_field()}}
    <div class="control-group">
        <label class="control-label">Page Title :</label>
        <div class="controls">
            <input class="span11" name="page_title" placeholder="Page Title" type="text">
        </div>
    </div>
    <div class="control-group">
        <label class="control-label">Page Subtitle :</label>
        <div class="controls">
            <input class="span11" name="page_subtitle" placeholder="Page Subtitle" type="text">
        </div>
    </div>
    <div class="control-group">
        <label class="control-label">Featured Image</label>
        <div class="controls">
            <input type="file" name="page_featured_image" id="input-file"/>
        </div>
    </div>
    <div class="control-group">
        <label class="control-label">Body</label>
        <div class="controls">
            <textarea class="textarea_editor span10" name="page_body" rows="10" placeholder="Enter text ..."></textarea>
        </div>
    </div>
    <div class="control-group">
        <label class="control-label">Pages Options</label>

         <div id="pageOptions" class=form-inline">
             <div class="AddMore">
                <div class="form-group">
                    <label for="email">Option Title:</label>
                    <input type="text" class="form-control" id="page_opton_title" placeholder="Enter Option Title" name="page_options_title[]">
                </div>
                <div class="form-group">
                    <label for="pwd">Option Body:</label>
                    <textarea class="textarea_editor span10" name="page_options_body[]" rows="5" placeholder="Enter Option text ..."></textarea>
                </div>
                 <div class="form-group">
                     <a href="#">Add More</a>
                 </div>
             </div>
        </div>

    </div>

    <div class="form-actions">
        <button type="submit" class="btn btn-success">Save</button>
    </div>
</form>
