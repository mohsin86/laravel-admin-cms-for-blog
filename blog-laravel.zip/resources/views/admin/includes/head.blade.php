<?php
/**
 * Created by PhpStorm.
 * User: mohsin
 * Date: 8/26/2017
 * Time: 8:04 PM
 */
?>
<title>Matrix Admin</title>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<link rel="stylesheet" href="{{asset('backend/css/bootstrap.min.css')}}" />
<meta name="csrf-token" content="{{ csrf_token() }}">
<link rel="stylesheet" href="{{asset('backend/css/bootstrap-responsive.min.css')}}" />
<link rel="stylesheet" href="{{asset('backend/css/fullcalendar.css')}}" />
<link rel="stylesheet" href="{{asset('backend/css/matrix-style.css')}}" />
<link rel="stylesheet" href="{{asset('backend/css/matrix-media.css')}}" />

<link rel="stylesheet" href="{{asset('backend/css/select2.css')}}" />
<link rel="stylesheet" href="{{asset('backend/css/uniform.css')}}" />
<link rel="stylesheet" href="{{asset('backend/css/bootstrap-wysihtml5.css')}}" />


<link href="{{asset('backend/font-awesome/css/font-awesome.css')}}" rel="stylesheet" />
<link rel="stylesheet" href="{{asset('backend/css/jquery.gritter.css')}}" />
<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,700,800' rel='stylesheet' type='text/css'>
