<?php
/**
 * Created by PhpStorm.
 * User: mohsin
 * Date: 8/26/2017
 * Time: 12:21 PM
 */
?>
<div class="container">
    <div class="col-md-8">
        <p class="copyright">Copyright: <span>2017</span> . Developed by <a href="http://www.dragonitbd.com">dragonitbd</a></p>
    </div>
    <div class="col-md-4">
        <!-- Social Media -->
        <ul class="social">
            <li>
                <a href="#" class="Facebook">
                    <i class="ion-social-facebook"></i>
                </a>
            </li>
            <li>
                <a href="#" class="Twitter">
                    <i class="ion-social-twitter"></i>
                </a>
            </li>
            <li>
                <a href="#" class="Linkedin">
                    <i class="ion-social-linkedin"></i>
                </a>
            </li>
            <li>
                <a href="#" class="Google Plus">
                    <i class="ion-social-googleplus"></i>
                </a>
            </li>
        </ul>
    </div>
</div>
